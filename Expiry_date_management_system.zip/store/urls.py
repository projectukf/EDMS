from django.urls import path

from .views import (
    productsview,
    productslistview,
    qr,
    qrurl
   
)

urlpatterns = [
    # path('products/', DeliveryListView.as_view(), name='products'),
    # path('create-supplier/', create_supplier, name='create-supplier'),
    # path('delivery-list/', DeliveryListView.as_view(), name='delivery-list'),
    path('products/', productsview, name='products'),
    path('productslist/', productslistview, name='products-list'),
    path('qr/', qr, name='qr'),

    path('qrapi/',qrurl.as_view(),name='qrapi'),
]
