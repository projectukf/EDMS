from django.shortcuts import render, redirect
from django.views.generic import ListView
from django.contrib.auth.decorators import login_required
from rest_framework.response import Response
from rest_framework.viewsets import *
from rest_framework.views import APIView
from rest_framework import status, generics
from user.models import User
from rest_framework import permissions

from .models import Products, QrCode

from datetime import datetime, date  
from datetime import timedelta 
import random
# Create your views here.
@login_required(login_url='gov-login')
def qr(request):
   if request.method=="POST":
      data = request.POST

      product_id = data.get("product_id")
      exp_date = data.get("exp_date")
      qty = int(data.get("qty"))
      qr_code=QrCode.objects.filter(org_id=str(request.user),product_id=product_id,created_date=date.today()).first()
      if qr_code is None:
        print(qr_code)
        for x in range(qty):
            while True:
                qr_id = random.randint(0,9999999999)
                qr_code=QrCode.objects.filter(qr_id=str(qr_id)).first()
                if qr_code is None:
                    break
            
            d = date.today() + timedelta(days=int(exp_date))
            QrCode.objects.create(qr_id=str(qr_id),org_id=str(request.user),product_id=product_id,exp_date=d)
   qr_code=QrCode.objects.filter(org_id=str(request.user),product_id=product_id)
   return render(request,"qr.html",{'qr_code':qr_code})

@login_required(login_url='gov-login')
def productsview(request):
    if request.method == "POST":
        data = request.POST

        Pro_obj = Products.objects.create(
            name = data.get("name"),
            product_id = data.get("product_id"),
            org_id = str(request.user),
            qty = data.get("qty"),
            status = True,
            exp_time = data.get("exp_time")
        )
        Pro_obj.save()
        
        products = Products.objects.filter(org_id = request.user)
        context = {
        'products': products
        }
        return render(request, 'gov/product_list.html', context)
        # return redirect('some-view-name', context)
    return render(request, 'gov/create_product.html')


@login_required(login_url='gov-login')
def productslistview(request):
    products = Products.objects.filter(org_id = request.user)
    context = {
    'products': products
    }
    return render(request, 'gov/product_list.html', context)


class qrurl(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, *args, **kwargs):
        data = {
            'task': 123, 
        }
        return Response(data, status=status.HTTP_200_OK)
