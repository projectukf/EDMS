from msilib.schema import Class
from django.shortcuts import render,redirect
from rest_framework.views import APIView# normal view can written API data
from rest_framework.response import Response# get a perticular response every thing is okey then give 200 response
from rest_framework import status # basically sent back status
from django.contrib import messages
from django.contrib.auth.models import User
from .serializers import *
from django.contrib.auth.hashers import make_password
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login as lg, logout,login
from rest_framework.exceptions import (
 APIException,               #for api exception
 ValidationError
)
import datetime
import base64
import os
from .models import *
import requests
from .forms import LoginForm
# from store.models import Product, Supplier, Buyer, Order
def logout_page(request):
    logout(request)
    return redirect('login')

def govlogout_page(request):
    logout(request)
    return redirect('gov-login')


def login_page(request):
    forms = LoginForm()
    if request.method == 'POST':
        forms = LoginForm(request.POST)
        if forms.is_valid():
            username = forms.cleaned_data['username']
            password = forms.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user:
                login(request, user)
                return redirect('dashboard')
    context = {'form': forms}
    return render(request, 'users/login.html', context)

class GovLogin(APIView):
    def get(self,request):
        # print("ok")
        return Response({"detail":"success"},status=status.HTTP_200_OK,template_name='govlogin.html')

    def post(self,request):
        ser = validateUser(data=request.data)
        if ser.is_valid():


            user = User.objects.filter(username=request.POST["username"]).first()
            print("user",user)
            if user:
                serializer = AuthTokenSerializer(data=request.data)
                
                if serializer.is_valid():
                    user = serializer.validated_data['user']
                    
                    # if user.last_login:
                    lg(request, user)
                    return redirect("gov-dashboard")
                    # else:
                    #     lg(request, user)
                        
                    #     return redirect("profile")
                else:
                    
                    error_list = [serializer.errors[error][0] for error in serializer.errors]
                    err = error_list[0].split("string='")
                    print("error",err)
                    return Response({"messages":"error","detail":err[0]},status=status.HTTP_400_BAD_REQUEST,template_name='govlogin.html')
            else:
                print("error")
                return Response({"messages":"error","detail":"User not exists"},status=status.HTTP_400_BAD_REQUEST,template_name='govlogin.html')


        else:
            error_list = [ser.errors[error][0] for error in ser.errors]
            err = error_list[0].split("string='")
            print("error",err)
            return Response({"messages":"error","detail":err[0]},status=status.HTTP_400_BAD_REQUEST,template_name='govlogin.html')


class UserLogin(APIView):
    def get(self,request):
        # print("ok")
        return Response({"detail":"success"},status=status.HTTP_200_OK,template_name='login.html')

    def post(self,request):
        ser = validateUser(data=request.data)
        if ser.is_valid():


            user = User.objects.filter(username=request.POST["username"]).first()
            print("user",user)
            if user:
                serializer = AuthTokenSerializer(data=request.data)
                
                if serializer.is_valid():
                    user = serializer.validated_data['user']
                    
                    # if user.last_login:
                    lg(request, user)
                    return redirect("dashboard")
                    # else:
                    #     lg(request, user)
                        
                    #     return redirect("profile")
                else:
                    
                    error_list = [serializer.errors[error][0] for error in serializer.errors]
                    err = error_list[0].split("string='")
                    print("error",err)
                    return Response({"messages":"error","detail":err[0]},status=status.HTTP_400_BAD_REQUEST,template_name='login.html')
            else:
                print("error")
                return Response({"messages":"error","detail":"User not exists"},status=status.HTTP_400_BAD_REQUEST,template_name='login.html')


        else:
            error_list = [ser.errors[error][0] for error in ser.errors]
            err = error_list[0].split("string='")
            print("error",err)
            return Response({"messages":"error","detail":err[0]},status=status.HTTP_400_BAD_REQUEST,template_name='login.html')




class RegisterUser(APIView):
    def get(self,request):
        
        return Response({"detail":"success"},status=status.HTTP_200_OK,template_name='register.html')

    def post(self,request):
        # print("set",request.data)
        userserializer = SerializerUser(data=request.data)
        # print("1212")
        if userserializer.is_valid():
            # print("ok")
            # print(request.data['org_name'])
            new_user = userserializer.save(password=make_password(userserializer.validated_data['password']))
            org_obj = Organisation.objects.create(user=new_user,org_name=request.data['org_name'])
        else:
           
            error_list = [userserializer.errors[error][0] for error in userserializer.errors]
            err = error_list[0].split("string='")
            return Response({"messages":"error","detail":err[0]},status=status.HTTP_400_BAD_REQUEST,template_name='register.html')

        return redirect('gov-login')
        # return Response({"detail":"success"},status=status.HTTP_200_OK,template_name='register.html')



class Dashboard(APIView):
    def get(self,request):
        user= request.user
        

        return Response({"detail":"success"},status=status.HTTP_200_OK,template_name='dashboard.html') 

@login_required(login_url='gov-login')
def GovDashboard(request):
    # total_product = Product.objects.count()
    # total_supplier = Supplier.objects.count()
    # total_buyer = Buyer.objects.count()
    # total_oder = Order.objects.count()
    # orders = Order.objects.all().order_by('-id')
    # context = {
    #     'product': total_product,
    #     'supplier': total_supplier,
    #     'buyer': total_buyer,
    #     'order': total_oder,
    #     'orders': orders
    # }
    # return render(request, 'gov_dashboard.html', context)
    return render(request, 'gov_dashboard.html')