
from django.urls import path
from .import views
from .views import logout_page, login_page, govlogout_page
urlpatterns = [
    path('govlogin',views.GovLogin.as_view(),name='gov-login'),
    path('login',views.UserLogin.as_view(),name='login'),
    path('register',views.RegisterUser.as_view(),name='register'),
    path('dashboard',views.Dashboard.as_view(),name='dashboard'),
    path('gov_dashboard', views.GovDashboard, name='gov-dashboard'),
    path('govlogout/', govlogout_page, name='gov-logout'),
    path('logout/', logout_page, name='logout'),
    path('store-login/', login_page, name='store-login'),
    path('store-logout/', logout_page, name='store-login'),

    

]